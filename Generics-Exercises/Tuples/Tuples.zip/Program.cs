﻿using System;

namespace Tuples
{
    class Program
    {
        static void Main(string[] args)
        {

            string[] nameTownInput = Console.ReadLine().Split();
            string firstName = nameTownInput[0];
            string lastName = nameTownInput[1];
            string address = nameTownInput[2];

            string[] nameBeerInput = Console.ReadLine().Split();
            string name = nameBeerInput[0];
            int liters = int.Parse(nameBeerInput[1]);

            string[] numbersInput = Console.ReadLine().Split();
            int integer = int.Parse(numbersInput[0]);
            double doubly = double.Parse(numbersInput[1]);

            MyTuple<string, string> nameTown = new MyTuple<string, string>($"{firstName} {lastName}", address);

            MyTuple<string, int> nameBeer = new MyTuple<string, int>(name, liters);

            MyTuple<int, double> numbers = new MyTuple<int, double>(integer, doubly);

            Console.WriteLine(nameTown.GetItems());
            Console.WriteLine(nameBeer.GetItems());
            Console.WriteLine(numbers.GetItems());
        }
    }
}
