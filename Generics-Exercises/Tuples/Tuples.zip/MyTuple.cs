﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tuples
{
    public class MyTuple<TheRock, JohnCena>
    {
        public MyTuple(TheRock number1, JohnCena number2)
        {
            Number1 = number1;
            Number2 = number2;
        }

        public TheRock Number1 { get; set; }
        public JohnCena Number2 { get; set; }

        public string GetItems()
        {
            return $"{Number1} -> {Number2}";
        }
    }
}
